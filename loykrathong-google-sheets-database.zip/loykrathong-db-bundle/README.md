# เชื่อมเว็บไซต์กับ Google Sheets

เว็บไซต์ส่งข้อมูลคำอธิษฐานไปยัง Google Apps Script Web App ซึ่งบันทึกลงชีต `คำอธิษฐาน` โดยตรง

## ตั้งค่าครั้งแรก

1. สร้าง Google Spreadsheet ใหม่ แล้วคัดลอก ID จาก URL รูปแบบ `https://docs.google.com/spreadsheets/d/SPREADSHEET_ID/edit`.
2. เปิด [script.google.com](https://script.google.com) แล้วสร้าง Apps Script project.
3. คัดลอกเนื้อหาใน `Code.gs` ไปวางในไฟล์ `Code.gs` ของโปรเจกต์.
4. ที่ **Project Settings → Script properties** เพิ่ม `SPREADSHEET_ID` โดยใช้ ID จากข้อ 1.
5. เลือกฟังก์ชัน `setupSheet` แล้วกด Run และอนุญาตให้สคริปต์เข้าถึง Google Sheets. สคริปต์จะสร้างแท็บ `คำอธิษฐาน` และหัวตาราง.
6. เลือก **Deploy → New deployment → Web app** ตั้ง **Execute as: Me** และ **Who has access: Anyone** จากนั้น Deploy.
7. คัดลอก Web app URL ที่ลงท้าย `/exec` แล้วแทนค่า `SHEET_WEBHOOK` ใน `script.js`.
8. เผยแพร่เว็บไซต์ใหม่ จากนั้นกรอกชื่อและคำอธิษฐานทดสอบ หน้าเว็บจะแสดงผลสำเร็จหลัง Google Apps Script ตอบกลับ `ok: true`.

เมื่อแก้ `Code.gs` ภายหลัง ให้เลือก **Deploy → Manage deployments → Edit → New version → Deploy** เพื่อให้ Web App ใช้โค้ดรุ่นล่าสุด.

## ข้อมูลที่บันทึก

เวลา, ชื่อ, คำอธิษฐาน, รหัสและชื่อสถานที่, รูปแบบกระทง, baseline, ขยะที่ลดได้, คาร์บอนที่หลีกเลี่ยงได้, ปี และแหล่งที่มาของเว็บไซต์

Apps Script ตรวจสอบความยาวชื่อ/คำอธิษฐานและตัวเลขผลกระทบ พร้อมป้องกันข้อความที่ขึ้นต้นด้วยเครื่องหมายสูตร spreadsheet.

## หมายเหตุเรื่องการเข้าถึง

Web App ที่ตั้งให้เข้าถึงได้จากทุกคนจะรับข้อมูลจากผู้เข้าชมโดยไม่ต้องล็อกอิน Google จึงไม่ควรเก็บข้อมูลอ่อนไหวในแบบฟอร์มนี้ หากพบสแปม ให้จำกัดการเข้าถึงหรือเพิ่มชั้นป้องกันก่อนใช้งานจริงในวงกว้าง.

/**
 * Google Sheets endpoint for the Phyathai 2 Loy Krathong site.
 * Set SPREADSHEET_ID in Project Settings > Script properties before deployment.
 */
const SHEET_NAME = 'คำอธิษฐาน';
const HEADERS = [
  'เวลาบันทึก', 'ชื่อผู้ร่วมอวยพร', 'คำอธิษฐาน', 'สถานที่ (รหัส)', 'สถานที่',
  'รูปแบบกระทง', 'ชนิดกระทงจริง (baseline)', 'ขยะที่ลดได้ (กก.)',
  'คาร์บอนที่หลีกเลี่ยงได้ (kgCO2e)', 'ปี', 'แหล่งที่มา'
];

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    const data = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    validate_(data);
    lock.waitLock(10000);

    const id = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
    if (!id) throw new Error('Missing SPREADSHEET_ID script property');
    const spreadsheet = SpreadsheetApp.openById(id);
    const sheet = spreadsheet.getSheetByName(SHEET_NAME) || spreadsheet.insertSheet(SHEET_NAME);
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(HEADERS);
      sheet.setFrozenRows(1);
    }

    // Prefix user text with an apostrophe so spreadsheet formulas are never evaluated.
    sheet.appendRow([
      new Date(), safeCell_(data.name), safeCell_(data.desc), safeCell_(data.location),
      safeCell_(data.locationLabel), safeCell_(data.krathong), safeCell_(data.baseline),
      Number(data.wasteKg), Number(data.avoidedCo2Kg), safeCell_(data.year), safeCell_(data.source)
    ]);
    return json_({ ok: true });
  } catch (error) {
    return json_({ ok: false, error: String(error && error.message || error) });
  } finally {
    if (lock.hasLock()) lock.releaseLock();
  }
}

function validate_(data) {
  if (!data || typeof data !== 'object') throw new Error('Invalid request');
  if (!String(data.name || '').trim() || String(data.name).length > 50) throw new Error('Invalid name');
  if (!String(data.desc || '').trim() || String(data.desc).length > 120) throw new Error('Invalid wish');
  if (!Number.isFinite(Number(data.wasteKg)) || !Number.isFinite(Number(data.avoidedCo2Kg))) {
    throw new Error('Invalid impact values');
  }
}

function safeCell_(value) {
  const text = String(value == null ? '' : value).slice(0, 1000);
  return /^[=+@\-]/.test(text) ? "'" + text : text;
}

function json_(value) {
  return ContentService.createTextOutput(JSON.stringify(value))
    .setMimeType(ContentService.MimeType.JSON);
}

/** Run once from the Apps Script editor to create the tab and header row. */
function setupSheet() {
  const id = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
  if (!id) throw new Error('Add SPREADSHEET_ID in Script properties first.');
  const spreadsheet = SpreadsheetApp.openById(id);
  const sheet = spreadsheet.getSheetByName(SHEET_NAME) || spreadsheet.insertSheet(SHEET_NAME);
  if (sheet.getLastRow() === 0) sheet.appendRow(HEADERS);
  sheet.setFrozenRows(1);
}
